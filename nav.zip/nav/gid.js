//game ids and strings
g = {
    Explore : "Explore",
    BossRoom : "BossRoom",
    
}

